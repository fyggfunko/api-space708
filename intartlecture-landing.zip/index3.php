<?php session_name("kaleo_lead"); session_start(); if (empty($_SESSION["lead_success"])) { header("Location: index2.php#lead-section", true, 303); exit; } ?>
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Découvrez la présentation de la plateforme automatisée évoquée dans ces vidéos. Prenez le temps d’examiner les explications, les limites et les risques avant toute décision.">
<title>intartlecture — Vidéo 3</title><link rel="stylesheet" href="./assets/site.css">
<script src="./assets/site.js" defer></script></head><body data-step="3">
<header><a class="brand" href="index.html"><span class="mark" aria-hidden="true">i</span> intartlecture</a>
</header>
<main><section class="watch" aria-label="PRÉSENTATION VIDÉO">
<div class="video-shell" id="video-shell" data-playback="G02O1uyX01Ol4lx14Bm4K921mgm00n8hDZTxuM786RpkQw" data-error="Le lecteur ne peut pas être chargé. Réessayez ou revenez plus tard." data-retry="Réessayer">
<div id="video-placeholder"><p>Présentation en français</p><button class="button" id="load-video" type="button">Regarder la vidéo</button></div></div>
<section class="intro"><p class="brand-kicker">intartlecture</p><p class="eyebrow">PRÉSENTATION VIDÉO</p><h1>Une présentation à regarder,<br><span class="accent">à votre rythme.</span></h1><p class="lede">Découvrez la présentation de la plateforme automatisée évoquée dans ces vidéos. Prenez le temps d’examiner les explications, les limites et les risques avant toute décision.</p></section>
<p class="video-status" id="video-status" role="status"></p>
<div class="video-caption"><p>Pour avoir une vue complète, regardez la vidéo jusqu’à la fin. Vous pouvez mettre en pause ou passer en plein écran à tout moment. La lecture ne peut pas être avancée ni reculée.</p></div>

<p class="small">Le visionnage ne crée aucun compte et ne transmet aucune demande de rappel.</p>
<div id="completed" hidden role="status"><p>La vidéo est terminée. Prenez le temps de vérifier les informations avant de poursuivre.</p><button id="replay" type="button" class="button secondary">Revoir depuis le début</button></div>

<noscript><p>JavaScript est nécessaire pour charger le lecteur vidéo.</p></noscript>
</section>
<aside class="risk"><h2>À savoir avant de regarder</h2><p>Cette présentation concerne une plateforme automatisée liée à des perspectives de revenus. Aucun revenu ni rendement n’est garanti. Si une opération financière vous est proposée, vous pouvez perdre tout ou partie du capital engagé. Vérifiez l’identité du prestataire, ses autorisations, les frais et les conditions avant tout engagement.</p></aside>
<section class="faq"><h2>Avant de poursuivre</h2><details><summary>Dois-je laisser mes coordonnées pour regarder ?</summary><p>Non. Les vidéos restent accessibles sans formulaire, sans inscription et sans obligation d’achat.</p></details><details><summary>Puis-je mettre la vidéo en pause ?</summary><p>Oui. Lecture, volume et plein écran restent disponibles. La barre de lecture ne permet pas d’avancer ou de reculer.</p></details><details><summary>Le visionnage garantit-il un résultat ?</summary><p>Non. Une présentation ne garantit aucun résultat. Ne vous engagez pas sur la seule base d’une promesse de revenus.</p></details></section>
<section class="legal" aria-label="Éditeur et contact">
<h2 id="operator">Éditeur et contact</h2><p>Éditeur : KALEO 1 LTD.</p>
<p>N° de société : 17383494</p>
<p>Adresse : 28 Kingfisher Road, Upminster, RM14 1ER, United Kingdom</p>
<p>Téléphone : <a href="tel:+447412655101">+44 7412 655101</a></p>
<h2 id="privacy">Confidentialité</h2><p>Cette version ne comporte ni formulaire de contact, ni pixel publicitaire, ni outil de mesure d’audience ajouté par le site. Le serveur d’hébergement peut traiter des données techniques de connexion ; ses paramètres et durées de conservation doivent être précisés par l’éditeur. Le lecteur Mux n’est chargé que sur demande. Mux et son fournisseur de diffusion peuvent alors traiter votre adresse IP, des informations sur votre navigateur et des données de lecture pour fournir le service. Les conditions du prestataire vidéo s’appliquent également. Le site ne mémorise pas votre progression après fermeture de la page.</p><a href="https://www.mux.com/privacy" target="_blank" rel="noopener noreferrer">Informations Mux sur la confidentialité ↗</a>
<h2 id="terms">Conditions d’utilisation</h2><p>Les vidéos sont mises à disposition pour consultation. Leur visionnage ne constitue pas une inscription, un contrat ou une recommandation personnalisée. Cette page ne permet aucun paiement, dépôt ou ouverture de compte. Aucun résultat financier n’est promis par le site. Avant toute utilisation commerciale, l’éditeur doit vérifier le contenu des vidéos et ses droits de diffusion.</p>
</section></main>
<footer><p><strong>intartlecture</strong><br>Présentation de la plateforme · Aucun résultat financier garanti.</p><nav><a href="#operator">Éditeur et contact</a><a href="#privacy">Confidentialité</a><a href="#terms">Conditions d’utilisation</a></nav><p class="draft">Version de préparation — contenu vidéo et informations réglementaires à vérifier avant diffusion publicitaire.</p></footer></body></html>